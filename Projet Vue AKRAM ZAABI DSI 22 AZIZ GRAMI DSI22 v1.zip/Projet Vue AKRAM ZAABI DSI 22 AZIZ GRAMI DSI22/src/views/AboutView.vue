<template>
  <div class="about">
    <h1>Hi</h1>
  </div>
</template>
<style></style>
